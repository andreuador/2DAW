<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Benvingut Pàgina</title>
    </head>
    <body>
        <form action="401Get.php" method="POST">
            <label for="name">Nom: </label>
            <input type="text" id="name" name="name">

            <button type="submit">
        </form>
    </body>
</html>
